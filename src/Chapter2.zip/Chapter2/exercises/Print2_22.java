package Chapter2.exercises;

public class Print2_22 {
    public static void main(String[] args){
        System.out.println("*");
        System.out.println("***");
        System.out.println("*****");
        System.out.print("****");
        System.out.println("**");

    }

}
