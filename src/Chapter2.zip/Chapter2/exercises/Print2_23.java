package Chapter2.exercises;

public class Print2_23 {
    public static void main(String[] args){
        System.out.printf("%s%n%s%n%s%n%s%n", " *", " ***", "*****", " ***", " *");
    }
}
