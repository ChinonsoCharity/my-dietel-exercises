package Chapter2.exercises;

public class PrintFormat {
    public static void main(String[] args){
        System.out.printf(" ****%n ******%n*******%n ******%n ****%n");
    }

}
