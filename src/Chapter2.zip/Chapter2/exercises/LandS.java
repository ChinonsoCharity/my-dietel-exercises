package Chapter2.exercises;

import java.util.Scanner;

public class LandS {
    public static void main(String[] args){

        Scanner check = new Scanner(System.in);

        System.out.print("Enter 5 numbers");

//        int numbers[] = check.nextInt(){a,b,c, d,e,};
//
//        int smallest = numbers[0];
//        int largetst = numbers[0];
//
//        for (int q = 1; q < numbers.length; q++) {
//
//            if (numbers[q] > largetst)
//                largetst = numbers[q];
//
//            else if (numbers[q] < smallest)
//                smallest = numbers[q];
//        }
//
//        System.out.printf("Largest Number is  %d", largetst);
//        System.out.printf("Smallest Number is %d", smallest);

    }
}
