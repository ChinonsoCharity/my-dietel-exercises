package Chapter2.exercises;

public class Pt {
    public static void main(String[] args){
        System.out.print("*");
        System.out.print("***");
        System.out.print("*****");
        System.out.print("****");
        System.out.println("**");
    }
}
